"use strict";
var nameValidation = function () {
    console.log("Hello");
    var x = document.getElementById('Ename').value;
    console.log(x);
    var regex = /^[a-zA-Z.]+$/;
    if (x.length < 2 || !x.match(regex)) {
        document.getElementById("Ename").style.border = "1px solid red";
        document.getElementById("empErrors").style.display = "block";
        document.getElementById("empErrors").innerHTML = "Enter a valid name.Must not contain any special character or any Number literal";
        return false;
    }
    else {
        showNextEmpField();
    }
};
var genderValidation = function () {
    var x = document.getElementsByName('gender');
    if (!x[0].checked && !x[1].checked) {
        document.getElementById("empErrors").style.display = "block";
        document.getElementById("empErrors").innerHTML = "Please select a valid gender";
        return false;
    }
    else {
        showNextEmpField();
    }
};
var emailValidation = function () {
    var x = document.getElementById("Eemail").value;
    var regex = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/;
    if (!x.match(regex)) {
        document.getElementById("Eemail").style.border = "1px solid red";
        document.getElementById("empErrors").style.display = "block";
        document.getElementById("empErrors").innerHTML = "Email must comtain '@' and '.' Ex- abc@gmail.com";
        return false;
    }
    else {
        showNextEmpField();
    }
};
var passwordValidation = function () {
    var x = document.getElementById("password").value;
    if (x.length < 8) {
        document.getElementById("password").style.border = "1px solid red";
        document.getElementById("empErrors").style.display = "block";
        document.getElementById("empErrors").innerHTML = "Length of password must be equal to or greater than 8.<br>Password must contain an special character Ex-!@#$%^&*()_,<br>a small alphabet (a-z), a capital alphabet(A-Z) and one number(0-9)";
        return false;
    }
    else {
        document.getElementById("empErrors").style.display = "block";
        //At least one uppercase letter, one lowercase letter and one number:
        var npass = /^(?=.*?[A-Za-z])(?=.*?[0-9]).{8,}$/;
        //At least one uppercase letter, one lowercase letter, one number and one special character:
        var spass = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
        if (x.match(spass)) {
            document.getElementById("password").style.border = "1px solid green";
            document.getElementById("empErrors").style.color = "green";
            document.getElementById("empErrors").innerHTML = "Strong Password";
            showNextEmpField();
        }
        else if (x.match(npass)) {
            document.getElementById("password").style.border = "1px solid orange";
            document.getElementById("empErrors").style.color = "orange";
            document.getElementById("empErrors").innerHTML = "Normal Password";
            return false;
        }
        else {
            document.getElementById("password").style.border = "1px solid red";
            document.getElementById("empErrors").style.display = "block";
            document.getElementById("empErrors").innerHTML = "Password is too weak";
            return false;
        }
    }
};
var confirmPasswordValidation = function () {
    var pass = document.getElementById("password").value;
    var cpass = document.getElementById("confirmPassword").value;
    if (pass != cpass) {
        document.getElementById("confirmPassword").style.border = "1px solid red";
        document.getElementById("empErrors").style.display = "block";
        document.getElementById("empErrors").innerHTML = "Not matches with the password provided";
        return false;
    }
    else {
        showNextEmpField();
    }
};
var contactValidation = function () {
    var x = document.getElementById("contactNum").value;
    var regex = /[0-9]{10}/;
    if (!x.match(regex)) {
        document.getElementById("contactNum").style.border = "1px solid red";
        document.getElementById("empErrors").style.display = "block";
        document.getElementById("empErrors").innerHTML = "Enter a 10 digit contact number (include numbers only)";
        return false;
    }
    else {
        generateEmpId();
    }
};
var showEmpForm = function () {
    document.getElementById("nameform").style.display = "block";
};
var showNextEmpField = function () {
    document.getElementById("empErrors").style.display = "none";
    if (document.getElementById("nameform").style.display == "block") {
        document.getElementById("nameform").style.display = "none";
        document.getElementById("genderform").style.display = "block";
    }
    else if (document.getElementById("genderform").style.display == "block") {
        document.getElementById("genderform").style.display = "none";
        document.getElementById("emailform").style.display = "block";
    }
    else if (document.getElementById("emailform").style.display == "block") {
        document.getElementById("emailform").style.display = "none";
        document.getElementById("passwordform").style.display = "block";
    }
    else if (document.getElementById("passwordform").style.display == "block") {
        document.getElementById("passwordform").style.display = "none";
        document.getElementById("cpasswordform").style.display = "block";
    }
    else if (document.getElementById("cpasswordform").style.display == "block") {
        document.getElementById("cpasswordform").style.display = "none";
        document.getElementById("contactform").style.display = "block";
    }
};
var generateEmpId = function () {
    document.getElementById("empErrors").style.display = "none";
    document.getElementById("contactform").style.display = "none";
    document.getElementById("generatedEmpId").style.display = "block";
    var id = Math.round(Math.random() * 100000);
    document.getElementById("generatedEmpId").innerHTML = "Your Employee Id is :  EMP" + id;
};
var showVehicleForm = function () {
    document.getElementById("vcompanyform").style.display = "block";
};
var showNextVehicleField = function () {
    if (document.getElementById("vcompanyform").style.display == "block") {
        document.getElementById("vcompanyform").style.display = "none";
        document.getElementById("vmodelform").style.display = "block";
    }
    else if (document.getElementById("vmodelform").style.display == "block") {
        document.getElementById("vmodelform").style.display = "none";
        document.getElementById("vtypeform").style.display = "block";
    }
    else if (document.getElementById("vtypeform").style.display == "block") {
        document.getElementById("vtypeform").style.display = "none";
        document.getElementById("vnumberform").style.display = "block";
    }
    else if (document.getElementById("vnumberform").style.display == "block") {
        document.getElementById("vnumberform").style.display = "none";
        document.getElementById("vempidform").style.display = "block";
    }
    else if (document.getElementById("vempidform").style.display == "block") {
        document.getElementById("vempidform").style.display = "none";
        document.getElementById("videntityform").style.display = "block";
    }
};
var showParkingPrices = function () {
    document.getElementById("videntityform").style.display = "none";
    var vtype = document.getElementById("VType").value;
    if (vtype == "cycle") {
        document.getElementById("cycle").style.display = "block";
        document.getElementById("motorcycle").style.display = "none";
        document.getElementById("fourWheeler").style.display = "none";
    }
    else if (vtype == "motorcycle") {
        document.getElementById("cycle").style.display = "none";
        document.getElementById("motorcycle").style.display = "block";
        document.getElementById("fourWheeler").style.display = "none";
    }
    else if (vtype == "fourwheeler") {
        document.getElementById("cycle").style.display = "none";
        document.getElementById("motorcycle").style.display = "none";
        document.getElementById("fourWheeler").style.display = "block";
    }
};
var calculateAmount = function () {
    var vtype = document.getElementById("VType").value;
    var amount = 0;
    if (vtype == "cycle") {
        var pricetype = document.getElementsByName("cprice")[0];
        if (pricetype[0].checked)
            amount = 5;
        else if (pricetype[1].checked)
            amount = 100;
        else if (pricetype[2].checked)
            amount = 500;
    }
    else if (vtype == "motorcycle") {
        var pricetype = document.getElementsByName("mcprice")[0];
        if (pricetype[0].checked)
            amount = 10;
        else if (pricetype[1].checked)
            amount = 200;
        else if (pricetype[2].checked)
            amount = 1000;
    }
    else if (vtype == "fourwheeler") {
        var pricetype = document.getElementsByName("fwprice")[0];
        if (pricetype[0].checked)
            amount = 20;
        else if (pricetype[1].checked)
            amount = 500;
        else if (pricetype[2].checked)
            amount = 3500;
    }
    document.getElementById("totalamt").style.display = "block";
    document.getElementById("totalamt").innerHTML = "Total Amount to be paid : $" + amount;
};
