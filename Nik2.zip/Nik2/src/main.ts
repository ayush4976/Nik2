let nameValidation = () => {
    console.log("Hello");
    let x: string = (<HTMLInputElement>document.getElementById('Ename')).value;
    console.log(x);
    let regex = /^[a-zA-Z.]+$/ ;
    if (x.length<2 || !x.match(regex)) {
        (<HTMLInputElement>document.getElementById("Ename")).style.border = "1px solid red";
        (<HTMLInputElement>document.getElementById("empErrors")).style.display = "block";
        (<HTMLInputElement>document.getElementById("empErrors")).innerHTML = "Enter a valid name.Must not contain any special character or any Number literal";
        return false;
    }
    else {
        showNextEmpField();
    }
}


let genderValidation = () => {
    let x: any = document.getElementsByName('gender');
    if(!x[0].checked && !x[1].checked) {
        (<HTMLInputElement>document.getElementById("empErrors")).style.display = "block";
        (<HTMLInputElement>document.getElementById("empErrors")).innerHTML = "Please select a valid gender";
        return false;
    }
    else {
        showNextEmpField();
    }
}


let emailValidation = () => {
    let x = (<HTMLInputElement>document.getElementById("Eemail")).value;
    let regex = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/ ;
    if (!x.match(regex)) {
        (<HTMLInputElement>document.getElementById("Eemail")).style.border = "1px solid red";
        (<HTMLInputElement>document.getElementById("empErrors")).style.display = "block";
        (<HTMLInputElement>document.getElementById("empErrors")).innerHTML = "Email must comtain '@' and '.' Ex- abc@gmail.com";
        return false;
    }
    else {
        showNextEmpField();
    }
}
    
let passwordValidation = () => {
    let x = (<HTMLInputElement>document.getElementById("password")).value;
    if (x.length < 8) {
        (<HTMLInputElement>document.getElementById("password")).style.border = "1px solid red";
        (<HTMLInputElement>document.getElementById("empErrors")).style.display = "block";
        (<HTMLInputElement>document.getElementById("empErrors")).innerHTML = "Length of password must be equal to or greater than 8.<br>Password must contain an special character Ex-!@#$%^&*()_,<br>a small alphabet (a-z), a capital alphabet(A-Z) and one number(0-9)";
        return false;
    }
    else {
        (<HTMLInputElement>document.getElementById("empErrors")).style.display = "block";
        //At least one uppercase letter, one lowercase letter and one number:
        let npass = /^(?=.*?[A-Za-z])(?=.*?[0-9]).{8,}$/;
        //At least one uppercase letter, one lowercase letter, one number and one special character:
        let spass =/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
        
        if(x.match(spass)){
            (<HTMLInputElement>document.getElementById("password")).style.border = "1px solid green";
            (<HTMLInputElement>document.getElementById("empErrors")).style.color = "green";
            (<HTMLInputElement>document.getElementById("empErrors")).innerHTML = "Strong Password";
            showNextEmpField();
        }
        else if(x.match(npass)){
            (<HTMLInputElement>document.getElementById("password")).style.border = "1px solid orange";
            (<HTMLInputElement>document.getElementById("empErrors")).style.color = "orange";
            (<HTMLInputElement>document.getElementById("empErrors")).innerHTML = "Normal Password";
            return false;
        }
        else {
            (<HTMLInputElement>document.getElementById("password")).style.border = "1px solid red";
            (<HTMLInputElement>document.getElementById("empErrors")).style.display = "block";
            (<HTMLInputElement>document.getElementById("empErrors")).innerHTML = "Password is too weak";
            return false;
        }
    }
}

let confirmPasswordValidation = () => {
    let pass = (<HTMLInputElement>document.getElementById("password")).value;
    let cpass = (<HTMLInputElement>document.getElementById("confirmPassword")).value;
    if (pass != cpass) {
        (<HTMLInputElement>document.getElementById("confirmPassword")).style.border = "1px solid red";
        (<HTMLInputElement>document.getElementById("empErrors")).style.display = "block";
        (<HTMLInputElement>document.getElementById("empErrors")).innerHTML = "Not matches with the password provided";
        return false;
    }
    else {
        showNextEmpField();
    }
}

let contactValidation = () => {
    let x = (<HTMLInputElement>document.getElementById("contactNum")).value;
    let regex = /[0-9]{10}/;
    if (!x.match(regex)) {
        (<HTMLInputElement>document.getElementById("contactNum")).style.border = "1px solid red";
        (<HTMLInputElement>document.getElementById("empErrors")).style.display = "block";
        (<HTMLInputElement>document.getElementById("empErrors")).innerHTML = "Enter a 10 digit contact number (include numbers only)";
        return false;
    }
    else {
        generateEmpId();
    }
}

let showEmpForm = () => {
    (<HTMLInputElement>document.getElementById("nameform")).style.display = "block";
}

let showNextEmpField = () =>{
    (<HTMLInputElement>document.getElementById("empErrors")).style.display = "none";
    if ((<HTMLInputElement>document.getElementById("nameform")).style.display == "block"){
        (<HTMLInputElement>document.getElementById("nameform")).style.display = "none";
        (<HTMLInputElement>document.getElementById("genderform")).style.display = "block";
    }
    else if((<HTMLInputElement>document.getElementById("genderform")).style.display == "block"){
        (<HTMLInputElement>document.getElementById("genderform")).style.display = "none";
        (<HTMLInputElement>document.getElementById("emailform")).style.display = "block";
    }
    else if((<HTMLInputElement>document.getElementById("emailform")).style.display == "block"){
        (<HTMLInputElement>document.getElementById("emailform")).style.display = "none";
        (<HTMLInputElement>document.getElementById("passwordform")).style.display = "block";
    }
    else if((<HTMLInputElement>document.getElementById("passwordform")).style.display == "block"){
        (<HTMLInputElement>document.getElementById("passwordform")).style.display = "none";
        (<HTMLInputElement>document.getElementById("cpasswordform")).style.display = "block";
    }
    else if((<HTMLInputElement>document.getElementById("cpasswordform")).style.display == "block"){
        (<HTMLInputElement>document.getElementById("cpasswordform")).style.display = "none";
        (<HTMLInputElement>document.getElementById("contactform")).style.display = "block";
    }
}

let generateEmpId = () => {
    (<HTMLInputElement>document.getElementById("empErrors")).style.display = "none";
    (<HTMLInputElement>document.getElementById("contactform")).style.display = "none";
    (<HTMLInputElement>document.getElementById("generatedEmpId")).style.display = "block";
    let id: number = Math.round(Math.random()*100000);
    (<HTMLInputElement>document.getElementById("generatedEmpId")).innerHTML = "Your Employee Id is :  EMP"+ id;
}

let showVehicleForm = () => {
    (<HTMLInputElement>document.getElementById("vcompanyform")).style.display = "block";
}

let showNextVehicleField = () => {
    if ((<HTMLInputElement>document.getElementById("vcompanyform")).style.display == "block"){
        (<HTMLInputElement>document.getElementById("vcompanyform")).style.display = "none";
        (<HTMLInputElement>document.getElementById("vmodelform")).style.display = "block";
    }
    else if((<HTMLInputElement>document.getElementById("vmodelform")).style.display == "block"){
        (<HTMLInputElement>document.getElementById("vmodelform")).style.display = "none";
        (<HTMLInputElement>document.getElementById("vtypeform")).style.display = "block";
    }
    else if((<HTMLInputElement>document.getElementById("vtypeform")).style.display == "block"){
        (<HTMLInputElement>document.getElementById("vtypeform")).style.display = "none";
        (<HTMLInputElement>document.getElementById("vnumberform")).style.display = "block";
    }
    else if((<HTMLInputElement>document.getElementById("vnumberform")).style.display == "block"){
        (<HTMLInputElement>document.getElementById("vnumberform")).style.display = "none";
        (<HTMLInputElement>document.getElementById("vempidform")).style.display = "block";
    }
    else if((<HTMLInputElement>document.getElementById("vempidform")).style.display == "block"){
        (<HTMLInputElement>document.getElementById("vempidform")).style.display = "none";
        (<HTMLInputElement>document.getElementById("videntityform")).style.display = "block";
    }
}

let showParkingPrices = () => {
    (<HTMLInputElement>document.getElementById("videntityform")).style.display = "none";
    let vtype: string = (<HTMLInputElement>document.getElementById("VType")).value;
    if (vtype == "cycle") {
        (<HTMLInputElement>document.getElementById("cycle")).style.display = "block";
        (<HTMLInputElement>document.getElementById("motorcycle")).style.display = "none";
        (<HTMLInputElement>document.getElementById("fourWheeler")).style.display = "none";
    }
    else if (vtype == "motorcycle") {
        (<HTMLInputElement>document.getElementById("cycle")).style.display = "none";
        (<HTMLInputElement>document.getElementById("motorcycle")).style.display = "block";
        (<HTMLInputElement>document.getElementById("fourWheeler")).style.display = "none";
    }
    else if (vtype == "fourwheeler") {
        (<HTMLInputElement>document.getElementById("cycle")).style.display = "none";
        (<HTMLInputElement>document.getElementById("motorcycle")).style.display = "none";
        (<HTMLInputElement>document.getElementById("fourWheeler")).style.display = "block";
    }
}

let calculateAmount = () => {
    let vtype = (<HTMLInputElement>document.getElementById("VType")).value;
    let amount = 0;
    if (vtype == "cycle") {
        let pricetype: any = <HTMLScriptElement>document.getElementsByName("cprice")[0];
        if(pricetype[0].checked)
        amount = 5;
        else if(pricetype[1].checked)
        amount = 100;
        else if(pricetype[2].checked)
        amount = 500;
    }
    else if (vtype == "motorcycle") {
        let pricetype: any = <HTMLScriptElement>document.getElementsByName("mcprice")[0];
        if(pricetype[0].checked)
        amount = 10;
        else if(pricetype[1].checked)
        amount = 200;
        else if(pricetype[2].checked)
        amount = 1000;
    }
    else if (vtype == "fourwheeler") {
        let pricetype: any = <HTMLScriptElement>document.getElementsByName("fwprice")[0];
        if(pricetype[0].checked)
        amount = 20;
        else if(pricetype[1].checked)
        amount = 500;
        else if(pricetype[2].checked)
        amount = 3500;
    }
    (<HTMLInputElement>document.getElementById("totalamt")).style.display = "block";
    (<HTMLInputElement>document.getElementById("totalamt")).innerHTML = "Total Amount to be paid : $"+amount;
}